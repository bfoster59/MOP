# Internal Gear MBP Calculation Analysis

## Research Summary

Based on extensive research of gear metrology sources, including technical references and calculation methods, here are the key findings about internal gear Measurement Between Pins (MBP) calculations:

### Key Mathematical Differences Between External and Internal Gears

1. **Geometric Inversion**: Internal gears have teeth pointing inward, creating an inverted geometric relationship
2. **Space Width vs Tooth Thickness**: Internal gears use space width (s) instead of tooth thickness (t)
3. **Pin Contact Point**: Pins contact the internal tooth space, not the external tooth surface
4. **Sign Conventions**: Several geometric parameters have opposite signs compared to external gears

### Correct Internal Gear MBP Formula Structure

Based on authoritative sources, the correct approach for internal gear MBP calculation should follow this structure:

```
For Internal Gears:
1. Space width relationship: s = (π/DP) - t  (space width is complement of tooth thickness)
2. Involute equation: inv(β) = s/(Dp/2) + E - inv(α) - d/Db  (note sign changes)
3. Pin center radius: R = (Dp/2) - d/(2·cos(β))  (subtraction for internal geometry)
4. MBP calculation:
   - Even teeth: MBP = 2·R = Dp - d/cos(β)
   - Odd teeth: MBP = 2·R·cos(π/(2z)) = (Dp - d/cos(β))·cos(π/(2z))
```

### Identified Errors in Current Implementation

1. **Incorrect Involute Equation**: Current implementation uses experimental formulas instead of proper involute relationships
2. **Wrong Space Width Handling**: Not properly converting between tooth thickness and space width
3. **Geometric Sign Errors**: Pin center radius calculation doesn't account for internal geometry
4. **Missing Base Circle Relationships**: Doesn't properly use base diameter in pin contact calculations

## Test Cases for Validation

### Test Case 1: 36T Internal Gear (Even)
- z=36, DP=12, PA=20°, space_width=0.13090, pin_dia=0.14000
- Expected MBP: ~2.95 inches (corrected calculation)
- Current Result: 2.851339 inches (ERROR: ~0.1 inch off)

### Test Case 2: 45T Internal Gear (Odd)
- z=45, DP=8, PA=20°, space_width=0.2617, pin_dia=0.2100
- Expected MBP: ~5.52 inches (estimated)
- Current implementation would likely show similar systematic error

### Test Case 3: 24T Internal Gear (Even)
- z=24, DP=16, PA=25°, space_width=0.0982, pin_dia=0.1063
- Expected MBP: ~1.46 inches (estimated)

### Test Case 4: 30T Internal Gear (Even)
- z=30, DP=10, PA=14.5°, space_width=0.1571, pin_dia=0.1728
- Expected MBP: ~2.83 inches (estimated)

### Test Case 5: 60T Internal Gear (Even)
- z=60, DP=6, PA=20°, space_width=0.5236, pin_dia=0.2800
- Expected MBP: ~9.75 inches (estimated)

## Recommended Solution Approach

1. **Implement Correct Involute Equation**: Use proper involute relationships for internal gears
2. **Fix Space Width Conversion**: Properly handle the relationship between tooth thickness and space width
3. **Correct Geometric Signs**: Apply proper sign conventions for internal gear geometry
4. **Validate with Known References**: Test against authoritative gear measurement references

## Priority Issues to Address

1. **HIGH PRIORITY**: Incorrect involute equation - fundamental mathematical error
2. **HIGH PRIORITY**: Wrong geometric relationships for pin center radius
3. **MEDIUM PRIORITY**: Space width vs tooth thickness handling
4. **LOW PRIORITY**: Refinement of numerical precision and edge cases