#!/usr/bin/env python3
"""
Test implementation based on the reference calculator formula
From the screenshot: Internal gear dimension between pins calculation
"""

import math

# High-precision PI constant
PI_HIGH_PRECISION = 3.1415926535897932384626433832795028841971693993751

def inv(x: float) -> float:
    """Involute function: inv(x) = tan(x) - x"""
    return math.tan(x) - x

def inv_inverse(y: float, x0: float = 0.5) -> float:
    """Invert involute: solve tan(x) - x = y with Newton-Raphson"""
    x = float(x0)
    
    for iteration in range(250):
        cos_x = math.cos(x)
        tan_x = math.tan(x)
        
        # Function: f(x) = tan(x) - x - y
        f = tan_x - x - y
        
        # Derivative: f'(x) = sec²(x) - 1 = 1/cos²(x) - 1
        cos_x_squared = cos_x * cos_x
        df = (1.0 / cos_x_squared) - 1.0
        
        if abs(df) < 1e-18:
            break
            
        step = f / df
        x -= step
        
        if abs(step) < 1e-16 and abs(f) < 1e-16:
            break
    
    return x

def reference_calculator_method(N: int, DP: float, An_deg: float, Tn: float, D: float):
    """
    Implement the reference calculator approach from the screenshot
    
    Key formula from screenshot:
    In_Bd = pi/N - td/PD - dD/BD + InAd
    
    Parameters:
    N: Number of teeth
    DP: Diametral pitch  
    An_deg: Normal pressure angle (degrees)
    Tn: Normal arc tooth thickness on pitch diameter
    D: Ball/pin diameter
    """
    
    print(f"=== REFERENCE CALCULATOR METHOD ===")
    print(f"Inputs: N={N}, DP={DP}, An={An_deg}°, Tn={Tn:.5f}, D={D:.3f}")
    print()
    
    # Convert angle to radians
    An = An_deg * (PI_HIGH_PRECISION / 180.0)
    
    # Basic calculations
    PD = N / DP  # Pitch diameter
    BD = PD * math.cos(An)  # Base diameter
    InAd = inv(An)  # Involute function of pressure angle
    
    print(f"Pitch diameter (PD): {PD:.6f}")
    print(f"Base diameter (BD): {BD:.6f}")
    print(f"Involute of An (InAd): {InAd:.8f}")
    
    # Key formula from screenshot:
    # In_Bd = pi/N - td/PD - dD/BD + InAd
    # Note: td/PD should be the tooth thickness divided by pitch diameter
    # For internal gears, we need to work with space width
    # Convert tooth thickness to space width: space = pi/DP - tooth_thickness
    
    space_width = (PI_HIGH_PRECISION / DP) - Tn
    print(f"Calculated space width: {space_width:.6f}")
    
    # Apply the reference formula (modified for space width):
    # In_Bd = pi/N - space_width/PD - D/BD + InAd  
    In_Bd = (PI_HIGH_PRECISION / N) - (space_width / PD) - (D / BD) + InAd
    
    print(f"Involute function In_Bd: {In_Bd:.8f}")
    
    # Solve for pressure angle at pin center
    Bd = inv_inverse(In_Bd)
    Bd_deg = Bd * (180.0 / PI_HIGH_PRECISION)
    
    print(f"Pressure angle to pin center (Bd): {Bd_deg:.6f}°")
    
    # Diameter of pin centers
    CC = BD / math.cos(Bd)
    print(f"Diameter of pin centers (CC): {CC:.8f}")
    
    # Dimension between pins
    if N % 2 == 0:
        # Even teeth: DO = CC - D
        DO = CC - D
        method = "even"
    else:
        # Odd teeth: DO = cos(90/N) * CC - D
        cos_factor = math.cos(90.0 * PI_HIGH_PRECISION / (180.0 * N))
        DO = cos_factor * CC - D
        method = "odd"
    
    print(f"Method: {method} teeth")
    print(f"Dimension between pins (DO): {DO:.8f}")
    
    return {
        'method': method,
        'PD': PD,
        'BD': BD,
        'InAd': InAd,
        'space_width': space_width,
        'In_Bd': In_Bd,
        'Bd_deg': Bd_deg,
        'CC': CC,
        'DO': DO
    }

if __name__ == "__main__":
    # Test with parameters from screenshot
    print("Testing with screenshot parameters:")
    print("N=12, DP=24, An=20°, Tn=0.06545, D=0.060")
    print()
    
    result = reference_calculator_method(12, 24.0, 20.0, 0.06545, 0.060)
    
    print()
    print("=== EXPECTED FROM SCREENSHOT ===")
    print("Dimension between pins: 0.444260199552884404")
    print(f"Our calculated result:  {result['DO']:.15f}")
    print(f"Difference: {abs(result['DO'] - 0.444260199552884404):.15f}")