#!/usr/bin/env python3
"""
Corrected Internal Gear MBP Calculation
Based on proper involute gear theory and authoritative sources
"""

import math
from dataclasses import dataclass
from typing import Optional

# High-precision mathematical constants
PI_HIGH_PRECISION = 3.1415926535897932384626433832795028841971693993751

def inv(x: float) -> float:
    """Involute function: inv(x) = tan(x) - x"""
    return math.tan(x) - x

def inv_inverse(y: float, x0: float = 0.5) -> float:
    """Invert involute: solve tan(x) - x = y with Newton-Raphson"""
    x = float(x0)
    
    for iteration in range(250):
        cos_x = math.cos(x)
        tan_x = math.tan(x)
        
        # Function: f(x) = tan(x) - x - y
        f = tan_x - x - y
        
        # Derivative: f'(x) = sec²(x) - 1 = 1/cos²(x) - 1
        cos_x_squared = cos_x * cos_x
        df = (1.0 / cos_x_squared) - 1.0
        
        if abs(df) < 1e-18:
            break
            
        step = f / df
        x -= step
        
        if abs(step) < 1e-16 and abs(f) < 1e-16:
            break
    
    return x

@dataclass
class MBPResult:
    method: str
    MBP: float
    Dp: float
    Db: float
    E: float
    space_width: float
    inv_alpha: float
    inv_beta: float
    beta_rad: float
    beta_deg: float
    pin_center_radius: float
    factor: float

def corrected_mbp_internal_dp(z: int, DP: float, alpha_deg: float, space_width: float, d: float) -> MBPResult:
    """
    Corrected Measurement Between Pins (MBP) for internal spur gears.
    
    Args:
        z: Number of teeth
        DP: Diametral pitch [1/inch]
        alpha_deg: Pressure angle [degrees]
        space_width: Circular space width at pitch circle [inches]
        d: Pin diameter [inches]
    
    Returns:
        MBPResult with corrected calculation
    
    Based on proper involute gear theory:
    1. For internal gears, pins sit in tooth spaces
    2. Space width is used instead of tooth thickness
    3. Geometric relationships are inverted compared to external gears
    4. Proper involute equation: inv(β) = s/R_p + E - inv(α) - d/R_b
    """
    
    if z <= 0 or DP <= 0 or d <= 0 or space_width <= 0:
        raise ValueError("All inputs must be positive")
    
    # Convert to high-precision types
    z_precise = float(z)
    DP_precise = float(DP)
    alpha_deg_precise = float(alpha_deg)
    space_width_precise = float(space_width)
    d_precise = float(d)
    
    # High-precision angle conversion
    alpha = alpha_deg_precise * (PI_HIGH_PRECISION / 180.0)
    
    # Basic geometry
    Dp = z_precise / DP_precise  # Pitch diameter
    Rp = Dp / 2.0  # Pitch radius
    Db = Dp * math.cos(alpha)  # Base diameter
    Rb = Db / 2.0  # Base radius
    E = PI_HIGH_PRECISION / z_precise  # Angular spacing between teeth
    inv_alpha = inv(alpha)
    
    # CORRECTED INVOLUTE EQUATION FOR INTERNAL GEARS
    # For internal gears, the involute relationship is:
    # inv(β) = space_width/Rp + E - inv(α) - d/Rb
    # Note the ADDITION of E (not subtraction as in external gears)
    # and the space width instead of tooth thickness
    inv_beta = space_width_precise / Rp + E - inv_alpha - d_precise / Rb
    
    # Solve for contact angle β
    beta = inv_inverse(inv_beta)
    
    # CORRECTED PIN CENTER RADIUS FOR INTERNAL GEARS
    # For internal gears, pins sit inside the gear, so the geometry is inverted
    # Pin center radius = Pitch radius - pin offset
    # Pin offset = (pin_radius) / cos(β)
    pin_offset = (d_precise / 2.0) / math.cos(beta)
    pin_center_radius = Rp - pin_offset
    
    # Determine measurement method and calculate MBP
    if z % 2 == 0:
        # Even tooth count: 2-pin method (diametrically opposite pins)
        method = "2-pin"
        factor = 1.0
        MBP = 2.0 * pin_center_radius
    else:
        # Odd tooth count: 3-pin method (measurement across same-side pair)
        method = "odd tooth"
        factor = math.cos(PI_HIGH_PRECISION / (2.0 * z_precise))
        MBP = 2.0 * pin_center_radius * factor
    
    return MBPResult(
        method=method,
        MBP=MBP,
        Dp=Dp,
        Db=Db,
        E=E,
        space_width=space_width_precise,
        inv_alpha=inv_alpha,
        inv_beta=inv_beta,
        beta_rad=beta,
        beta_deg=beta * (180.0 / PI_HIGH_PRECISION),
        pin_center_radius=pin_center_radius,
        factor=factor
    )

def validate_with_test_cases():
    """Run validation test cases"""
    
    print("=== CORRECTED INTERNAL GEAR MBP VALIDATION ===\n")
    
    # Test Case 1: 36T Internal Gear (Even)
    print("Test Case 1: 36T Internal Gear")
    result1 = corrected_mbp_internal_dp(36, 12.0, 20.0, 0.13090, 0.14000)
    print(f"MBP: {result1.MBP:.6f} inches")
    print(f"Method: {result1.method}")
    print(f"Pin center radius: {result1.pin_center_radius:.6f} inches")
    print(f"Contact angle beta: {result1.beta_deg:.3f} deg")
    print()
    
    # Test Case 2: 45T Internal Gear (Odd) 
    print("Test Case 2: 45T Internal Gear")
    result2 = corrected_mbp_internal_dp(45, 8.0, 20.0, 0.2617, 0.2100)
    print(f"MBP: {result2.MBP:.6f} inches")
    print(f"Method: {result2.method}")
    print(f"Pin center radius: {result2.pin_center_radius:.6f} inches")
    print(f"Contact angle beta: {result2.beta_deg:.3f} deg")
    print()
    
    # Test Case 3: 24T Internal Gear (Even)
    print("Test Case 3: 24T Internal Gear")
    result3 = corrected_mbp_internal_dp(24, 16.0, 25.0, 0.0982, 0.1063)
    print(f"MBP: {result3.MBP:.6f} inches")
    print(f"Method: {result3.method}")
    print(f"Pin center radius: {result3.pin_center_radius:.6f} inches")
    print(f"Contact angle beta: {result3.beta_deg:.3f} deg")
    print()
    
    # Test Case 4: 30T Internal Gear (Even)
    print("Test Case 4: 30T Internal Gear")
    result4 = corrected_mbp_internal_dp(30, 10.0, 14.5, 0.1571, 0.1728)
    print(f"MBP: {result4.MBP:.6f} inches")
    print(f"Method: {result4.method}")
    print(f"Pin center radius: {result4.pin_center_radius:.6f} inches")
    print(f"Contact angle beta: {result4.beta_deg:.3f} deg")
    print()
    
    # Test Case 5: 60T Internal Gear (Even)
    print("Test Case 5: 60T Internal Gear")
    result5 = corrected_mbp_internal_dp(60, 6.0, 20.0, 0.5236, 0.2800)
    print(f"MBP: {result5.MBP:.6f} inches")
    print(f"Method: {result5.method}")
    print(f"Pin center radius: {result5.pin_center_radius:.6f} inches")
    print(f"Contact angle beta: {result5.beta_deg:.3f} deg")
    print()

if __name__ == "__main__":
    validate_with_test_cases()