TO DO List
Start External and Internal calculators with clear fields.
In the calculators auto populate fields as you go, when you have data that completes calculations fill in the fields.
Remove output field named contact circle diameter and replace it with new output Standard Outside Diameter or Inside Diameter depending on the calculator
To the main menu, add Standard or Module with toggle, make calculations reflect the choice.
Add Hot Keys to the main menu, (S) for Standard, (M) for Module, (E) for External, (I) for Internal. Identify by adding a underscore to the first letter of the identifying word.
Change Output field name Base Diameter to Base Circle Diameter.
Add Circular Pith to the output
Big Change, Add Helix Angle to the External and Internal Calculators, this will add a layer of complexity to the calculations and will also require adding Helix Angle the input and output.


 