#!/usr/bin/env python3
"""
Debug the internal gear formula to understand space width vs tooth thickness
"""

import math

PI_HIGH_PRECISION = 3.1415926535897932384626433832795028841971693993751

def inv(x):
    return math.tan(x) - x

def debug_space_width_interpretation():
    # Screenshot test case
    N = 12
    DP = 24.0
    PA = 20.0
    input_t = 0.06545  # This is labeled as "tooth thickness"
    D = 0.060
    
    print("=== SPACE WIDTH INTERPRETATION DEBUG ===")
    print(f"Input parameters: N={N}, DP={DP}, PA={PA}°, input_t={input_t}, D={D}")
    print()
    
    # Convert to radians
    alpha = PA * (PI_HIGH_PRECISION / 180.0)
    inv_alpha = inv(alpha)
    
    # Basic geometry
    PD = N / DP
    BD = PD * math.cos(alpha)
    
    print(f"Pitch diameter (PD): {PD}")
    print(f"Base diameter (BD): {BD}")
    print(f"inv(alpha): {inv_alpha}")
    print()
    
    # Circular pitch
    circular_pitch = PI_HIGH_PRECISION / DP
    print(f"Circular pitch: {circular_pitch:.6f}")
    
    # Different interpretations of space width
    print("=== SPACE WIDTH INTERPRETATIONS ===")
    
    # Option 1: Input is tooth thickness, convert to space width
    space_width_1 = circular_pitch - input_t
    print(f"Option 1 - space_width = circular_pitch - tooth_thickness: {space_width_1:.6f}")
    
    # Option 2: Input is already space width  
    space_width_2 = input_t
    print(f"Option 2 - input is already space width: {space_width_2:.6f}")
    print()
    
    print("=== TESTING BOTH INTERPRETATIONS ===")
    
    # Test Option 1
    print("Option 1 Results:")
    inv_beta_1 = (PI_HIGH_PRECISION / N) - (space_width_1 / PD) - (D / BD) + inv_alpha
    print(f"  inv_beta: {inv_beta_1:.8f}")
    if inv_beta_1 > 0:
        print(f"  Valid positive involute value")
    else:
        print(f"  INVALID negative involute value!")
    print()
    
    # Test Option 2  
    print("Option 2 Results:")
    inv_beta_2 = (PI_HIGH_PRECISION / N) - (space_width_2 / PD) - (D / BD) + inv_alpha
    print(f"  inv_beta: {inv_beta_2:.8f}")
    if inv_beta_2 > 0:
        print(f"  Valid positive involute value")
    else:
        print(f"  INVALID negative involute value!")
    print()
    
    # The screenshot shows "Normal arc tooth thickness" = 0.06545
    # For internal gears, we need space width, not tooth thickness
    print("=== CONCLUSION ===")
    print("From screenshot: 'Normal arc tooth thickness on pitch diameter: Tn = 0.06545'")
    print("For internal gears, we need SPACE WIDTH, not tooth thickness")
    print("Therefore: space_width = circular_pitch - tooth_thickness")
    print(f"Correct space width = {space_width_1:.6f}")

if __name__ == "__main__":
    debug_space_width_interpretation()