#!/usr/bin/env python3
"""
Compare the two different approaches for internal gear calculations
"""

import math

PI_HIGH_PRECISION = 3.1415926535897932384626433832795028841971693993751

def inv(x):
    return math.tan(x) - x

def inv_inverse(y, x0=0.5):
    x = float(x0)
    for iteration in range(250):
        cos_x = math.cos(x)
        tan_x = math.tan(x)
        f = tan_x - x - y
        cos_x_squared = cos_x * cos_x
        df = (1.0 / cos_x_squared) - 1.0
        if abs(df) < 1e-18:
            break
        step = f / df
        x -= step
        if abs(step) < 1e-16 and abs(f) < 1e-16:
            break
    return x

def compare_approaches():
    # Parameters from screenshot
    N = 12  
    DP = 24.0
    An_deg = 20.0
    Tn = 0.06545  # tooth thickness
    D = 0.060     # pin diameter
    
    print("=== FORMULA COMPARISON ===")
    print(f"Parameters: N={N}, DP={DP}, An={An_deg}°, Tn={Tn}, D={D}")
    print()
    
    # Common calculations
    An = An_deg * (PI_HIGH_PRECISION / 180.0)
    PD = N / DP  # Pitch diameter  
    BD = PD * math.cos(An)  # Base diameter
    InAd = inv(An)
    
    # Space width calculation
    space_width = (PI_HIGH_PRECISION / DP) - Tn
    
    print("=== REFERENCE CALCULATOR APPROACH ===")
    print("Formula: In_Bd = pi/N - space_width/PD - D/BD + InAd")
    
    # Reference approach
    In_Bd_ref = (PI_HIGH_PRECISION / N) - (space_width / PD) - (D / BD) + InAd
    Bd_ref = inv_inverse(In_Bd_ref)
    CC_ref = BD / math.cos(Bd_ref) 
    MBP_ref = CC_ref - D
    
    print(f"In_Bd: {In_Bd_ref:.8f}")
    print(f"Bd: {Bd_ref * 180/PI_HIGH_PRECISION:.6f}°")
    print(f"CC: {CC_ref:.8f}")
    print(f"MBP: {MBP_ref:.8f}")
    print()
    
    print("=== CURRENT MOP.PY APPROACH ===") 
    print("Formula: inv(beta) = s/Rp + E - inv(alpha) - d/Rb")
    
    # Current MOP.py approach
    Rp = PD / 2.0
    Rb = BD / 2.0
    E = PI_HIGH_PRECISION / N
    
    inv_beta_mop = space_width / Rp + E - InAd - D / Rb
    beta_mop = inv_inverse(inv_beta_mop)
    pin_offset = (D / 2.0) / math.cos(beta_mop)
    R_pin_center = Rp - pin_offset
    MBP_mop = 2.0 * R_pin_center
    
    print(f"inv_beta: {inv_beta_mop:.8f}")
    print(f"beta: {beta_mop * 180/PI_HIGH_PRECISION:.6f}°")
    print(f"R_pin_center: {R_pin_center:.8f}")
    print(f"MBP: {MBP_mop:.8f}")
    print()
    
    print("=== COMPARISON ===")
    print(f"Reference result: {MBP_ref:.8f}")
    print(f"MOP.py result:    {MBP_mop:.8f}")
    print(f"Difference:       {abs(MBP_ref - MBP_mop):.8f}")
    print()
    
    # Let's analyze the formula differences step by step
    print("=== FORMULA ANALYSIS ===")
    print("Reference: In_Bd = pi/N - space_width/PD - D/BD + InAd")
    print("MOP.py:    inv_β = space_width/Rp + E - InAd - D/Rb")
    print()
    print("Term by term comparison:")
    
    term1_ref = PI_HIGH_PRECISION / N
    term1_mop = E  # E = pi/N, so these should be the same
    print(f"Term 1 - pi/N vs E:           {term1_ref:.8f} vs {term1_mop:.8f}")
    
    term2_ref = -space_width / PD
    term2_mop = space_width / Rp  # Rp = PD/2, so this is space_width/(PD/2) = 2*space_width/PD
    print(f"Term 2 - space/PD vs space/Rp: {term2_ref:.8f} vs {term2_mop:.8f}")
    
    term3_ref = -D / BD
    term3_mop = -D / Rb  # Rb = BD/2, so this is -D/(BD/2) = -2*D/BD  
    print(f"Term 3 - D/BD vs D/Rb:        {term3_ref:.8f} vs {term3_mop:.8f}")
    
    term4_ref = InAd
    term4_mop = -InAd
    print(f"Term 4 - InAd vs -InAd:       {term4_ref:.8f} vs {term4_mop:.8f}")
    
    print()
    print("KEY DIFFERENCES IDENTIFIED:")
    print("1. Space width term: Reference uses PD, MOP.py uses Rp (factor of 2)")
    print("2. Pin term: Reference uses BD, MOP.py uses Rb (factor of 2)") 
    print("3. InAd term: Reference adds it, MOP.py subtracts it (sign flip)")

if __name__ == "__main__":
    compare_approaches()